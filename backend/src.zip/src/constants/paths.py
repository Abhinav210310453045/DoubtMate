import os
PROMPT_PATHS=os.path.join(os.path.dirname(os.path.abspath(__file__)),'prompts')

PROMPT_FILE_PATHS={
    'Summarize':os.path.join(PROMPT_PATHS,'summary.txt')
}